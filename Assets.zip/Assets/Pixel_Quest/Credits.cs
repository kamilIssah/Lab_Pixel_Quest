/*

Art from https://kenney.nl
    Pixel Platformer - https://kenney.nl/assets/pixel-platformer
    Pixel Platformer Food Expansion - https://kenney.nl/assets/pixel-platformer-food-expansion
    Pixel Platformer Industrial Expansion - https://kenney.nl/assets/pixel-platformer-industrial-expansion
    Pixel Platformer Farm Expansion - https://kenney.nl/assets/pixel-platformer-farm-expansion
    Background Elements Redux - https://kenney.nl/assets/background-elements-redux

Art from https://craftpix.net
    Free Summer Pixel Art Backgrounds - https://craftpix.net/freebies/free-summer-pixel-art-backgrounds/

Font from https://www.1001fonts.com/
    Atlantis Font Family - https://www.1001fonts.com/atlantis-font.html

SFX from https://freesound.org
    Coins 1 - https://freesound.org/people/ProjectsU012/sounds/341695/
    Cute Bounce Jump.wav - https://freesound.org/people/Hemplock/sounds/618961/
    collect game pixel lose - https://freesound.org/people/Eponn/sounds/676811/
    Enemy Dying.wav - https://freesound.org/people/vox_artist/sounds/512166/
    Itemize - https://freesound.org/people/Scrampunk/sounds/345297/
    health_1.wav - https://freesound.org/people/zandernoriega/sounds/162387/
    Mouse Click.wav - https://freesound.org/people/MATRIXXX_/sounds/365648/

Music from https://freesound.org
    Game background Music loop short - https://freesound.org/people/yummie/sounds/410574/
    Game-Music-01 - https://freesound.org/people/Michael-DB/sounds/489035/
    Pixel Flute Melody Loop - https://freesound.org/people/orginaljun/sounds/531459/

*/