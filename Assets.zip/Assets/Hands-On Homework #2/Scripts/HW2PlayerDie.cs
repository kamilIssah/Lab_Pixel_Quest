using UnityEngine;

public class HW2PlayerDie : MonoBehaviour
{

}
